# cefet-web-carona

Trabalho de Programação para Web

Professor Flávio Coutinho

Engenharia de Computação

CEFET-MG : 2017/1

Grupo: Ana Cláudia Gomes e Bruno Maciel

O objetivo do nosso projeto é desenvolver um sistema que procura resolver um problema comum entre docentes e discentes do CEFET-MG - as caronas. Se alguém tem aula ou trabalha em outro campus, ou só quer ir para casa depois de um dia cheio, mas o intercampi está lotado e a passagem está cara, por que não tentar conseguir uma carona? O sistema permitirá o cadastro de locais de origem e destino e os horários disponíveis de quem vai oferecer a carona. Também será possível adicionar pontos de parada intermediários, como algum campus. Assim, quem estiver procurando uma carona, poderá consultar se existe algum trajeto correspondente à sua necessidade e, caso não encontre, o caroneiro pode deixar um pedido em uma lista de requisições de carona não atendidas.
